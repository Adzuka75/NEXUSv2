package dev.nexus.systemintelligence.data

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.buffer

data class SensorReading(
    val type: Int,
    val name: String,
    val vendor: String,
    val version: Int,
    val resolution: Float,
    val maxRange: Float,
    val values: List<Float>,
    val accuracy: Int,
    val timestampNanos: Long
)

data class DeviceOrientation(
    val azimuthDegrees: Float,
    val pitchDegrees: Float,
    val rollDegrees: Float,
    val hasAccelerometer: Boolean,
    val hasMagnetometer: Boolean
)

class SensorRepository(context: Context) {
    private val appContext = context.applicationContext
    private val manager: SensorManager? =
        appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

    fun available(): List<Sensor> = runCatching {
        manager?.getSensorList(Sensor.TYPE_ALL)?.sortedBy { it.type }.orEmpty()
    }.getOrDefault(emptyList())

    fun readings(sensor: Sensor, delay: Int): Flow<SensorReading> = callbackFlow {
        val sensorManager = manager
        if (sensorManager == null) {
            close(IllegalStateException("Sensor service unavailable"))
            return@callbackFlow
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                val values = event?.values?.takeIf { it.isNotEmpty() }?.toList() ?: return
                trySend(
                    SensorReading(
                        sensor.type, sensor.name, sensor.vendor, sensor.version,
                        sensor.resolution, sensor.maximumRange, values,
                        event.accuracy, event.timestamp
                    )
                )
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        val registered = runCatching {
            sensorManager.registerListener(listener, sensor, delay.coerceIn(SensorManager.SENSOR_DELAY_FASTEST, SensorManager.SENSOR_DELAY_NORMAL))
        }.getOrDefault(false)

        if (!registered) {
            close(IllegalStateException("Sensor registration failed: ${sensor.name}"))
            return@callbackFlow
        }

        awaitClose {
            runCatching { sensorManager.unregisterListener(listener, sensor) }
        }
    }.buffer(capacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)

    /**
     * Fuses accelerometer and magnetometer readings into absolute device attitude.
     * Uses a short-lived listener pair and unregisters both on cancellation.
     */
    fun orientationUpdates(delay: Int): Flow<DeviceOrientation> = callbackFlow {
        val sensorManager = manager
        if (sensorManager == null) {
            close(IllegalStateException("Sensor service unavailable"))
            return@callbackFlow
        }

        val accelerometer = runCatching {
            sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        }.getOrNull()
        val magnetometer = runCatching {
            sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)
        }.getOrNull()

        if (accelerometer == null) {
            close(IllegalStateException("Accelerometer unavailable"))
            return@callbackFlow
        }

        var gravity: FloatArray? = null
        var magnetic: FloatArray? = null
        val rotation = FloatArray(9)
        val inclination = FloatArray(9)
        val orientation = FloatArray(3)

        fun publish() {
            val g = gravity ?: return
            // Accelerometer-only attitude keeps the spirit level functional even
            // on devices without a magnetometer.
            val pitch = Math.toDegrees(
                kotlin.math.atan2(
                    -g[0].toDouble(),
                    kotlin.math.sqrt((g[1] * g[1] + g[2] * g[2]).toDouble())
                )
            ).toFloat()
            val roll = Math.toDegrees(kotlin.math.atan2(g[1].toDouble(), g[2].toDouble())).toFloat()

            val m = magnetic
            val azimuth = if (m != null && SensorManager.getRotationMatrix(rotation, inclination, g, m)) {
                SensorManager.getOrientation(rotation, orientation)
                ((Math.toDegrees(orientation[0].toDouble()).toFloat() % 360f) + 360f) % 360f
            } else 0f

            trySend(
                DeviceOrientation(
                    azimuthDegrees = azimuth,
                    pitchDegrees = pitch,
                    rollDegrees = roll,
                    hasAccelerometer = true,
                    hasMagnetometer = magnetometer != null && m != null
                )
            )
        }

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                val values = event?.values ?: return
                if (values.size < 3) return
                when (event.sensor?.type) {
                    Sensor.TYPE_ACCELEROMETER -> gravity = values.copyOf()
                    Sensor.TYPE_MAGNETIC_FIELD -> magnetic = values.copyOf()
                }
                publish()
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        val sampling = delay.coerceIn(SensorManager.SENSOR_DELAY_FASTEST, SensorManager.SENSOR_DELAY_NORMAL)
        val accelRegistered = runCatching {
            sensorManager.registerListener(listener, accelerometer, sampling)
        }.getOrDefault(false)
        if (!accelRegistered) {
            close(IllegalStateException("Unable to register accelerometer"))
            return@callbackFlow
        }

        if (magnetometer != null) {
            runCatching { sensorManager.registerListener(listener, magnetometer, sampling) }
        }

        awaitClose {
            runCatching { sensorManager.unregisterListener(listener) }
        }
    }.buffer(capacity = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
}
