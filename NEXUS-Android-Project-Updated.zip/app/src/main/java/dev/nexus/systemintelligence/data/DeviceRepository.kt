package dev.nexus.systemintelligence.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.os.StatFs
import android.view.Display
import android.view.WindowManager
import java.io.File
import java.util.concurrent.TimeUnit

data class DeviceSnapshot(
    val manufacturer: String,
    val model: String,
    val android: String,
    val api: Int,
    val securityPatch: String,
    val cpuAbi: String,
    val cores: Int,
    val totalRam: Long,
    val availableRam: Long,
    val storageTotal: Long,
    val storageFree: Long,
    val batteryPercent: Int,
    val batteryTempC: Float?,
    val batteryVoltageMv: Int?,
    val batteryStatus: String,
    val batteryTechnology: String,
    val uptime: String,
    val refreshRate: Float,
    val resolution: String,
    val density: Float,
    val processPssMb: Int
)

class DeviceRepository(private val context: Context) {
    fun read(): DeviceSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalStorage = stat.totalBytes
        val freeStorage = stat.availableBytes
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val temp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        val voltage = batteryIntent?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1) ?: -1
        val status = when (batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "CHARGING"
            BatteryManager.BATTERY_STATUS_FULL -> "FULL"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "DISCHARGING"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "NOT CHARGING"
            else -> "UNKNOWN"
        }
        val pss = Debug.MemoryInfo().also { Debug.getMemoryInfo(it) }.totalPss / 1024
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val display = wm.defaultDisplay
        val metrics = android.util.DisplayMetrics().also { display.getRealMetrics(it) }
        val refresh = display.refreshRate
        val uptimeSeconds = TimeUnit.MILLISECONDS.toSeconds(android.os.SystemClock.elapsedRealtime())
        val uptime = "%02d:%02d:%02d".format(uptimeSeconds / 3600, (uptimeSeconds % 3600) / 60, uptimeSeconds % 60)
        return DeviceSnapshot(
            Build.MANUFACTURER.orEmpty(), Build.MODEL.orEmpty(), Build.VERSION.RELEASE.orEmpty(),
            Build.VERSION.SDK_INT, Build.VERSION.SECURITY_PATCH.orEmpty(), Build.SUPPORTED_ABIS.firstOrNull().orEmpty(),
            Runtime.getRuntime().availableProcessors(), mem.totalMem, mem.availMem,
            totalStorage, freeStorage, pct, if (temp >= 0) temp / 10f else null,
            if (voltage >= 0) voltage else null, status,
            batteryIntent?.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY).orEmpty(), uptime,
            refresh, "${metrics.widthPixels} × ${metrics.heightPixels}", metrics.density, pss
        )
    }

    fun buildFingerprint(): String = Build.FINGERPRINT.orEmpty()
    fun supportedFeatures(): List<String> = context.packageManager.systemAvailableFeatures
        .mapNotNull { it.name }.sorted()
    fun memoryUsedFraction(s: DeviceSnapshot): Float =
        if (s.totalRam > 0) ((s.totalRam - s.availableRam).toFloat() / s.totalRam).coerceIn(0f, 1f) else 0f
    fun storageUsedFraction(s: DeviceSnapshot): Float =
        if (s.storageTotal > 0) ((s.storageTotal - s.storageFree).toFloat() / s.storageTotal).coerceIn(0f, 1f) else 0f
    fun formatBytes(bytes: Long): String {
        val gb = bytes / 1024.0 / 1024.0 / 1024.0
        return if (gb >= 1) "%.2f GB".format(gb) else "%.0f MB".format(bytes / 1024.0 / 1024.0)
    }
}
