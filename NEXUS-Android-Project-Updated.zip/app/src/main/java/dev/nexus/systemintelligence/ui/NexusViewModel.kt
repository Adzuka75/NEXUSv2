package dev.nexus.systemintelligence.ui

import android.app.Application
import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import dev.nexus.systemintelligence.data.DeviceOrientation
import dev.nexus.systemintelligence.data.DeviceRepository
import dev.nexus.systemintelligence.data.DeviceSnapshot
import dev.nexus.systemintelligence.data.SensorReading
import dev.nexus.systemintelligence.data.SensorRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sqrt

class NexusViewModel(app: Application) : AndroidViewModel(app) {
    private val deviceRepo = DeviceRepository(app)
    private val sensorRepo = SensorRepository(app)

    private val _snapshot = MutableStateFlow(deviceRepo.read())
    val snapshot: StateFlow<DeviceSnapshot> = _snapshot
    private val _sensors = MutableStateFlow(sensorRepo.available())
    val sensors: StateFlow<List<Sensor>> = _sensors
    private val _reading = MutableStateFlow<SensorReading?>(null)
    val reading: StateFlow<SensorReading?> = _reading
    private val _selectedSensor = MutableStateFlow<Sensor?>(null)
    val selectedSensor: StateFlow<Sensor?> = _selectedSensor
    private val _history = MutableStateFlow<List<Float>>(emptyList())
    val history: StateFlow<List<Float>> = _history

    private val _orientation = MutableStateFlow<DeviceOrientation?>(null)
    val orientation: StateFlow<DeviceOrientation?> = _orientation
    private val _orientationError = MutableStateFlow<String?>(null)
    val orientationError: StateFlow<String?> = _orientationError

    private var sensorJob: Job? = null
    private var orientationJob: Job? = null
    private var samplingDelay = SensorManager.SENSOR_DELAY_UI
    private var refreshJob: Job? = null
    private var filteredLux: Float? = null
    private var hostStarted = true
    private var toolsRequested = false

    init {
        refreshJob = viewModelScope.launch {
            while (isActive) {
                runCatching { deviceRepo.read() }.getOrNull()?.let { _snapshot.value = it }
                delay(1500)
            }
        }
    }

    fun selectSensor(sensor: Sensor?) {
        sensorJob?.cancel()
        sensorJob = null
        _selectedSensor.value = sensor
        _reading.value = null
        _history.value = emptyList()
        filteredLux = null
        if (sensor != null && hostStarted) startSelectedSensor(sensor)
    }

    private fun startSelectedSensor(sensor: Sensor) {
        sensorJob?.cancel()
        sensorJob = viewModelScope.launch {
            sensorRepo.readings(sensor, samplingDelay)
                .catch { error ->
                    if (error !is CancellationException) {
                        _reading.value = null
                        _selectedSensor.value = null
                    }
                }
                .collectLatest { raw ->
                    val reading = if (raw.type == Sensor.TYPE_LIGHT) {
                        val incoming = raw.values.firstOrNull()?.coerceAtLeast(0f) ?: return@collectLatest
                        val previous = filteredLux
                        // Higher response for small changes; still dampens noisy jumps.
                        val alpha = if (previous == null) 1f
                            else if (abs(incoming - previous) < 5f) 0.62f else 0.38f
                        val next = if (previous == null) incoming
                            else previous + alpha * (incoming - previous)
                        filteredLux = next
                        raw.copy(values = listOf(next) + raw.values.drop(1))
                    } else raw

                    _reading.value = reading
                    val magnitude = if (reading.values.size >= 3) {
                        sqrt(reading.values.take(3).sumOf { (it * it).toDouble() }).toFloat()
                    } else reading.values.firstOrNull() ?: 0f
                    _history.value = (_history.value + magnitude).takeLast(100)
                }
        }
    }

    fun startToolsSensors() {
        toolsRequested = true
        if (!hostStarted || orientationJob?.isActive == true) return
        _orientationError.value = null
        orientationJob = viewModelScope.launch {
            sensorRepo.orientationUpdates(SensorManager.SENSOR_DELAY_UI)
                .catch { error ->
                    if (error !is CancellationException) {
                        _orientationError.value = error.message ?: "Orientation sensors unavailable"
                        _orientation.value = null
                    }
                }
                .collect { _orientation.value = it }
        }
    }

    fun stopToolsSensors() {
        toolsRequested = false
        orientationJob?.cancel()
        orientationJob = null
        _orientation.value = null
        _orientationError.value = null
    }

    fun pauseSensorStreams() {
        hostStarted = false
        sensorJob?.cancel()
        sensorJob = null
        orientationJob?.cancel()
        orientationJob = null
        _orientation.value = null
    }

    fun resumeSensorStreams() {
        if (hostStarted) return
        hostStarted = true
        _selectedSensor.value?.let { startSelectedSensor(it) }
        if (toolsRequested) startToolsSensors()
    }

    fun setSamplingDelay(delay: Int) {
        samplingDelay = delay
        _selectedSensor.value?.let { selectSensor(it) }
    }

    fun fingerprint() = deviceRepo.buildFingerprint()
    fun features() = deviceRepo.supportedFeatures()
    fun formatBytes(v: Long) = deviceRepo.formatBytes(v)
    fun ramFraction(s: DeviceSnapshot) = deviceRepo.memoryUsedFraction(s)
    fun storageFraction(s: DeviceSnapshot) = deviceRepo.storageUsedFraction(s)

    override fun onCleared() {
        sensorJob?.cancel()
        orientationJob?.cancel()
        refreshJob?.cancel()
        super.onCleared()
    }
}
