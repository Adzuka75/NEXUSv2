package dev.nexus.systemintelligence.ui

import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.nexus.systemintelligence.data.DeviceOrientation
import dev.nexus.systemintelligence.data.DeviceSnapshot
import dev.nexus.systemintelligence.data.SensorReading
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.delay

// ───────────────────────── Palette ─────────────────────────
private val Cyan = Color(0xFF67E8F9)
private val Violet = Color(0xFF9B8CFF)
private val Magenta = Color(0xFFFF4FD8)
private val Lime = Color(0xFF7CFFB2)
private val Amber = Color(0xFFFFC857)
private val Coral = Color(0xFFFF6B6B)
private val Muted = Color(0xFF8197A5)
private val Deep = Color(0xFF05080D)
private val TrackColor = Color(0xFF13202B)
private const val DEG = 0.017453292f

private val LocalFx = compositionLocalOf { 0.8f }

private fun polar(c: Offset, r: Float, deg: Float): Offset =
    Offset(c.x + r * cos(deg * DEG), c.y + r * sin(deg * DEG))

// ───────────────────────── Root ─────────────────────────
@Composable
fun NexusApp(viewModel: NexusViewModel) {
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, viewModel) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> viewModel.resumeSensorStreams()
                Lifecycle.Event.ON_STOP -> viewModel.pauseSensorStreams()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) {
            viewModel.resumeSensorStreams()
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            viewModel.pauseSensorStreams()
        }
    }
    NexusTheme {
        var page by remember { mutableIntStateOf(0) }
        var showSettings by remember { mutableStateOf(false) }
        var fx by remember { mutableFloatStateOf(0.8f) }
        var sampling by remember { mutableIntStateOf(SensorManager.SENSOR_DELAY_UI) }
        val snapshot by viewModel.snapshot.collectAsStateWithLifecycle()
        val sensors by viewModel.sensors.collectAsStateWithLifecycle()
        val reading by viewModel.reading.collectAsStateWithLifecycle()
        val selected by viewModel.selectedSensor.collectAsStateWithLifecycle()
        val history by viewModel.history.collectAsStateWithLifecycle()
        val orientation by viewModel.orientation.collectAsStateWithLifecycle()
        val orientationError by viewModel.orientationError.collectAsStateWithLifecycle()

        LaunchedEffect(page) {
            if (page == 5) viewModel.startToolsSensors() else viewModel.stopToolsSensors()
        }

        CompositionLocalProvider(
            LocalFx provides fx,
            LocalContentColor provides MaterialTheme.colorScheme.onBackground
        ) {
            FuturisticBackground {
                Scaffold(
                    containerColor = Color.Transparent,
                    contentColor = MaterialTheme.colorScheme.onBackground,
                    topBar = { Header(snapshot) { showSettings = true } },
                    bottomBar = { NavBar(page) { page = it } }
                ) { padding ->
                    AnimatedContent(
                        targetState = page,
                        transitionSpec = {
                            (fadeIn(tween(380)) + slideInVertically(tween(380)) { it / 18 }) togetherWith fadeOut(tween(140))
                        },
                        label = "page",
                        modifier = Modifier.padding(padding)
                    ) { target ->
                        when (target) {
                            0 -> OverviewPage(snapshot, viewModel)
                            1 -> SensorsPage(sensors, selected, reading, history, viewModel)
                            2 -> PerformancePage(snapshot, viewModel)
                            3 -> BatteryPage(snapshot)
                            4 -> DevicePage(snapshot, viewModel)
                            else -> ToolsPage(orientation, orientationError)
                        }
                    }
                }
            }
        }
        if (showSettings) {
            SettingsDialog(
                fx = fx,
                onFx = { fx = it },
                sampling = sampling,
                onSampling = { sampling = it; viewModel.setSamplingDelay(it) },
                onDismiss = { showSettings = false }
            )
        }
    }
}

// ───────────────────────── Background / chrome ─────────────────────────
@Composable
private fun FuturisticBackground(content: @Composable BoxScope.() -> Unit) {
    val fx = LocalFx.current
    val t = rememberInfiniteTransition(label = "bg")
    val phase by t.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "phase")
    val drift by t.animateFloat(
        0f, 1f, infiniteRepeatable(tween(11000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "drift"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Deep)
            .drawBehind {
                val w = size.width
                val h = size.height
                val c1 = Offset(w * (0.1f + 0.6f * drift), h * 0.10f)
                val c2 = Offset(w * (0.9f - 0.6f * drift), h * 0.85f)
                drawCircle(
                    Brush.radialGradient(listOf(Cyan.copy(alpha = 0.22f * fx), Color.Transparent), center = c1, radius = w * 0.9f),
                    radius = w * 0.9f, center = c1
                )
                drawCircle(
                    Brush.radialGradient(listOf(Violet.copy(alpha = 0.20f * fx), Color.Transparent), center = c2, radius = w * 0.9f),
                    radius = w * 0.9f, center = c2
                )
                val step = 40.dp.toPx()
                val gridColor = Cyan.copy(alpha = 0.05f * fx)
                var y = phase * step - step
                while (y < h) {
                    drawLine(gridColor, Offset(0f, y), Offset(w, y), 1f)
                    y += step
                }
                var x = 0f
                while (x < w) {
                    drawLine(gridColor, Offset(x, 0f), Offset(x, h), 1f)
                    x += step
                }
                val sy = h * phase
                drawRect(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Cyan.copy(alpha = 0.10f * fx), Color.Transparent),
                        startY = sy - 150f, endY = sy + 150f
                    ),
                    topLeft = Offset(0f, sy - 150f), size = Size(w, 300f)
                )
            },
        content = content
    )
}

@Composable
private fun Header(s: DeviceSnapshot, onSettings: () -> Unit) {
    val t = rememberInfiniteTransition(label = "hdr")
    val shift by t.animateFloat(0f, 600f, infiniteRepeatable(tween(4500, easing = LinearEasing)), label = "shift")
    val pulse by t.animateFloat(0.3f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val titleBrush = Brush.linearGradient(
        listOf(Cyan, Violet, Magenta, Violet, Cyan),
        start = Offset(shift, 0f), end = Offset(shift + 300f, 0f), tileMode = TileMode.Mirror
    )
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Column {
                Text("N E X U S", style = TextStyle(brush = titleBrush, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 5.sp))
                Text("SYSTEM INTELLIGENCE  /  LOCAL", color = Muted, fontSize = 9.sp, letterSpacing = 1.8.sp)
            }
            IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Cyan) }
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(8.dp)
                    .graphicsLayer { alpha = pulse }
                    .background(Lime, CircleShape)
            )
            Spacer(Modifier.width(8.dp))
            Text("SYSTEM NOMINAL", color = Lime, fontSize = 10.sp, letterSpacing = 1.4.sp)
            Spacer(Modifier.weight(1f))
            Text("LIVE  •  ${s.uptime}", color = Muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun NavBar(page: Int, onSelect: (Int) -> Unit) {
    Column {
        Box(
            Modifier.fillMaxWidth().height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Cyan.copy(alpha = 0.7f), Violet.copy(alpha = 0.7f), Color.Transparent)))
        )
        NavigationBar(containerColor = Color(0xF2090F17), tonalElevation = 0.dp) {
            val items = listOf("Overview", "Sensors", "Performance", "Battery", "Device", "Tools")
            val icons = listOf(Icons.Default.Dashboard, Icons.Default.Sensors, Icons.Default.Memory, Icons.Default.BatteryFull, Icons.Default.PhoneAndroid, Icons.Default.Build)
            items.forEachIndexed { i, label ->
                NavigationBarItem(
                    selected = page == i,
                    onClick = { onSelect(i) },
                    icon = {
                        val sc by animateFloatAsState(if (page == i) 1.25f else 1f, tween(300), label = "navScale")
                        Icon(icons[i], label, modifier = Modifier.graphicsLayer { scaleX = sc; scaleY = sc })
                    },
                    label = { Text(label, fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Cyan, selectedTextColor = Cyan,
                        unselectedIconColor = Muted, unselectedTextColor = Muted,
                        indicatorColor = Cyan.copy(alpha = .14f)
                    )
                )
            }
        }
    }
}

@Composable
private fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Spacer(Modifier.height(2.dp))
        content()
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun SectionLabel(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(3.dp).height(14.dp).background(Brush.verticalGradient(listOf(Cyan, Violet))))
        Spacer(Modifier.width(8.dp))
        Text(text.uppercase(), color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Modifier.entrance(delayMs: Int): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        a.animateTo(1f, tween(600, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 44f
    }
}

@Composable
private fun Panel(
    modifier: Modifier = Modifier,
    accent: Color = Cyan,
    delayMs: Int = 0,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .entrance(delayMs)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xCC111B27), Color(0xCC0A1119))))
            .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = 0.65f), Color.Transparent, Violet.copy(alpha = 0.4f))), shape)
            .padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = .7.sp, modifier = Modifier.weight(.42f))
        Text(value, color = MaterialTheme.colorScheme.onSurface, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(.58f))
    }
}

// ───────────────────────── Gauges ─────────────────────────
@Composable
private fun RingCanvas(fraction: Float, color: Color, modifier: Modifier = Modifier, content: @Composable (Float) -> Unit) {
    val anim by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(1300, easing = FastOutSlowInEasing), label = "ring")
    val inf = rememberInfiniteTransition(label = "ringInf")
    val spin by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "spin")
    val breathe by inf.animateFloat(0.25f, 0.7f, infiniteRepeatable(tween(1700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val outer = size.minDimension / 2f
            val d = (outer - 14.dp.toPx()) * 2f
            val tl = Offset(center.x - d / 2f, center.y - d / 2f)
            val arcSize = Size(d, d)
            val dashLen = 4.dp.toPx()
            val gap = 8.dp.toPx()
            drawCircle(
                color.copy(alpha = 0.30f), radius = outer - 1.dp.toPx(), center = center,
                style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(dashLen, gap), spin * (dashLen + gap) * 12f))
            )
            drawArc(TrackColor, 135f, 270f, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (anim > 0.001f) {
                val span = 270f * anim
                drawArc(color.copy(alpha = breathe * 0.45f), 135f, span, false, tl, arcSize, style = Stroke(stroke * 2.4f, cap = StrokeCap.Round))
                drawArc(color, 135f, span, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
                val sparkLen = 12f.coerceAtMost(span)
                val sparkStart = 135f + spin * (span - sparkLen).coerceAtLeast(0f)
                drawArc(Color.White.copy(alpha = 0.85f), sparkStart, sparkLen, false, tl, arcSize, style = Stroke(stroke * 0.5f, cap = StrokeCap.Round))
            }
            val tickOuter = d / 2f - stroke * 1.4f
            val tickInner = tickOuter - 6.dp.toPx()
            val n = 36
            for (i in 0..n) {
                val f = i / n.toFloat()
                val a = 135f + 270f * f
                val lit = f <= anim
                drawLine(
                    if (lit) color.copy(alpha = 0.9f) else Color(0xFF1E3140),
                    polar(center, tickInner, a), polar(center, tickOuter, a), 1.dp.toPx()
                )
            }
        }
        content(anim)
    }
}

@Composable
private fun RingGauge(fraction: Float, label: String, sub: String, color: Color, valueOverride: String? = null) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = Muted, fontSize = 10.sp, letterSpacing = 1.6.sp)
        RingCanvas(fraction, color, Modifier.fillMaxWidth().aspectRatio(1f)) { a ->
            Text(valueOverride ?: "${(a * 100).toInt()}%", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Light)
        }
        Text(sub, color = color, fontSize = 9.sp, letterSpacing = 1.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun GlowBar(fraction: Float, modifier: Modifier = Modifier) {
    val anim by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(1300, easing = FastOutSlowInEasing), label = "bar")
    val inf = rememberInfiniteTransition(label = "barInf")
    val glow by inf.animateFloat(0.4f, 1f, infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    Canvas(modifier.fillMaxWidth().height(16.dp)) {
        val h = size.height
        val barH = 6.dp.toPx()
        val top = (h - barH) / 2f
        drawRoundRect(TrackColor, Offset(0f, top), Size(size.width, barH), CornerRadius(barH / 2f))
        val w = size.width * anim
        if (w > 0f) {
            drawRoundRect(
                Brush.horizontalGradient(listOf(Cyan, Violet, Magenta), startX = 0f, endX = size.width),
                Offset(0f, top), Size(w, barH), CornerRadius(barH / 2f)
            )
            val gc = Offset(w, h / 2f)
            drawCircle(
                Brush.radialGradient(listOf(Color.White.copy(alpha = glow), Color.Transparent), center = gc, radius = 9.dp.toPx()),
                radius = 9.dp.toPx(), center = gc
            )
        }
    }
}

@Composable
private fun MetricBar(title: String, value: String, detail: String, fraction: Float, delayMs: Int = 0) {
    Panel(delayMs = delayMs) {
        Text(title, color = Muted, fontSize = 9.sp, letterSpacing = 1.4.sp)
        Text(value, color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Light)
        GlowBar(fraction)
        Text(detail, color = Muted, fontSize = 9.sp, letterSpacing = .6.sp)
    }
}

// ───────────────────────── Pages ─────────────────────────
@Composable
private fun OverviewPage(s: DeviceSnapshot, vm: NexusViewModel) {
    PageColumn {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Panel(Modifier.weight(1f)) {
                RingGauge(
                    fraction = if (s.batteryPercent >= 0) s.batteryPercent / 100f else 0f,
                    label = "BATTERY", sub = s.batteryStatus, color = Cyan,
                    valueOverride = if (s.batteryPercent < 0) "—" else null
                )
            }
            Panel(Modifier.weight(1f), accent = Violet, delayMs = 90) {
                RingGauge(vm.ramFraction(s), "RAM LOAD", "${vm.formatBytes(s.availableRam)} FREE", Violet)
            }
        }
        SectionLabel("Storage matrix")
        MetricBar(
            "INTERNAL STORAGE", "${(vm.storageFraction(s) * 100).toInt()}%",
            "${vm.formatBytes(s.storageTotal - s.storageFree)} USED  /  ${vm.formatBytes(s.storageTotal)}",
            vm.storageFraction(s), delayMs = 150
        )
        SectionLabel("Device telemetry")
        Panel(delayMs = 220) {
            Text("${s.manufacturer} ${s.model}", color = MaterialTheme.colorScheme.onSurface, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            Text("ANDROID ${s.android}  •  API ${s.api}", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF203746)))
            InfoRow("PROCESSORS", "${s.cores} logical cores")
            InfoRow("ARCHITECTURE", s.cpuAbi)
            InfoRow("UPTIME", s.uptime)
            InfoRow("DISPLAY", "${s.resolution}  /  ${"%.0f".format(s.refreshRate)} Hz")
        }
        SectionLabel("Power")
        Panel(accent = Magenta, delayMs = 290) {
            InfoRow("BATTERY TEMP", s.batteryTempC?.let { "%.1f °C".format(it) } ?: "Unavailable")
            InfoRow("VOLTAGE", s.batteryVoltageMv?.let { "$it mV" } ?: "Unavailable")
            InfoRow("TECHNOLOGY", s.batteryTechnology.ifBlank { "Unavailable" })
        }
    }
}

@Composable
private fun PerformancePage(s: DeviceSnapshot, vm: NexusViewModel) {
    PageColumn {
        SectionLabel("CPU / memory laboratory")
        Panel(Modifier.fillMaxWidth(), accent = Violet) {
            RingGauge(vm.ramFraction(s), "SYSTEM RAM IN USE", "${vm.formatBytes(s.totalRam - s.availableRam)} USED", Violet)
        }
        Panel(delayMs = 100) {
            Text("PROCESSOR", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
            Text("${s.cores} LOGICAL PROCESSORS", color = Cyan, fontSize = 22.sp)
            InfoRow("ABI", s.cpuAbi)
            InfoRow("RUNTIME", System.getProperty("java.vm.name") ?: "Unavailable")
            InfoRow("CPU LOAD", "Not exposed to ordinary apps on many Android builds")
        }
        Panel(delayMs = 180) {
            SectionLabel("Memory detail")
            InfoRow("TOTAL RAM", vm.formatBytes(s.totalRam))
            InfoRow("AVAILABLE RAM", vm.formatBytes(s.availableRam))
            InfoRow("APP PSS", "${s.processPssMb} MB")
            InfoRow("UPTIME", s.uptime)
        }
        Text("Android restricts access to some per-core frequency and process metrics. Values not exposed by the OS are intentionally omitted.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun BatteryPage(s: DeviceSnapshot) {
    PageColumn {
        SectionLabel("Power management")
        Panel(Modifier.fillMaxWidth()) {
            RingGauge(
                fraction = if (s.batteryPercent >= 0) s.batteryPercent / 100f else 0f,
                label = "ENERGY RESERVE", sub = s.batteryStatus, color = if (s.batteryPercent in 0..15) Coral else Cyan,
                valueOverride = if (s.batteryPercent < 0) "—" else null
            )
        }
        Panel(accent = Magenta, delayMs = 120) {
            SectionLabel("Battery telemetry")
            InfoRow("TEMPERATURE", s.batteryTempC?.let { "%.1f °C".format(it) } ?: "Unavailable")
            InfoRow("VOLTAGE", s.batteryVoltageMv?.let { "$it mV" } ?: "Unavailable")
            InfoRow("TECHNOLOGY", s.batteryTechnology.ifBlank { "Unavailable" })
            InfoRow("HEALTH", "Not reliably exposed by standard public APIs")
            InfoRow("CYCLE COUNT", "Not available through standard public APIs")
        }
        Text("Battery temperature and voltage are reported by the device's battery service. This app does not estimate battery health or charging wattage.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun DevicePage(s: DeviceSnapshot, vm: NexusViewModel) {
    PageColumn {
        SectionLabel("Hardware identity")
        Panel {
            InfoRow("MANUFACTURER", s.manufacturer)
            InfoRow("MODEL", s.model)
            InfoRow("ANDROID", s.android)
            InfoRow("API LEVEL", s.api.toString())
            InfoRow("SECURITY PATCH", s.securityPatch.ifBlank { "Unavailable" })
            InfoRow("BUILD FINGERPRINT", vm.fingerprint())
            InfoRow("CPU ABI", s.cpuAbi)
            InfoRow("CORES", s.cores.toString())
            InfoRow("DISPLAY", s.resolution)
            InfoRow("DENSITY", "%.2f".format(s.density))
            InfoRow("REFRESH RATE", "%.2f Hz".format(s.refreshRate))
        }
        Panel(accent = Violet, delayMs = 100) {
            SectionLabel("Storage & memory")
            InfoRow("RAM", vm.formatBytes(s.totalRam))
            InfoRow("INTERNAL STORAGE", vm.formatBytes(s.storageTotal))
            InfoRow("FREE STORAGE", vm.formatBytes(s.storageFree))
        }
        Panel(accent = Magenta, delayMs = 180) {
            SectionLabel("Supported features")
            vm.features().take(35).forEach { Text(it, color = Muted, fontSize = 9.sp) }
        }
    }
}

// ───────────────────────── Sensors ─────────────────────────
private fun sensorLabel(type: Int): String = when (type) {
    Sensor.TYPE_ACCELEROMETER -> "ACCELEROMETER"
    Sensor.TYPE_MAGNETIC_FIELD -> "MAGNETOMETER"
    Sensor.TYPE_GYROSCOPE -> "GYROSCOPE"
    Sensor.TYPE_LIGHT -> "AMBIENT LIGHT"
    Sensor.TYPE_PRESSURE -> "BAROMETER"
    Sensor.TYPE_PROXIMITY -> "PROXIMITY"
    Sensor.TYPE_GRAVITY -> "GRAVITY"
    Sensor.TYPE_LINEAR_ACCELERATION -> "LINEAR ACCELERATION"
    Sensor.TYPE_ROTATION_VECTOR -> "ROTATION VECTOR"
    Sensor.TYPE_RELATIVE_HUMIDITY -> "HUMIDITY"
    Sensor.TYPE_AMBIENT_TEMPERATURE -> "AMBIENT TEMPERATURE"
    Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED -> "MAGNETOMETER (RAW)"
    Sensor.TYPE_GAME_ROTATION_VECTOR -> "GAME ROTATION"
    Sensor.TYPE_GYROSCOPE_UNCALIBRATED -> "GYROSCOPE (RAW)"
    Sensor.TYPE_SIGNIFICANT_MOTION -> "SIGNIFICANT MOTION"
    Sensor.TYPE_STEP_DETECTOR -> "STEP DETECTOR"
    Sensor.TYPE_STEP_COUNTER -> "STEP COUNTER"
    Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> "GEOMAGNETIC ROTATION"
    Sensor.TYPE_HEART_RATE -> "HEART RATE"
    else -> "SENSOR TYPE $type"
}

private fun sensorAccent(type: Int?): Color = when (type) {
    null -> Cyan
    Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GRAVITY, Sensor.TYPE_LINEAR_ACCELERATION -> Cyan
    Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED -> Magenta
    Sensor.TYPE_GYROSCOPE, Sensor.TYPE_GYROSCOPE_UNCALIBRATED -> Violet
    Sensor.TYPE_ROTATION_VECTOR, Sensor.TYPE_GAME_ROTATION_VECTOR, Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> Violet
    Sensor.TYPE_LIGHT -> Amber
    Sensor.TYPE_PROXIMITY -> Lime
    Sensor.TYPE_PRESSURE, Sensor.TYPE_RELATIVE_HUMIDITY, Sensor.TYPE_AMBIENT_TEMPERATURE -> Lime
    else -> Cyan
}

@Composable
private fun SensorsPage(
    sensors: List<Sensor>,
    selected: Sensor?,
    reading: SensorReading?,
    history: List<Float>,
    vm: NexusViewModel
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(2.dp))
        // Animation stays pinned at the top of the page; the list scrolls below it.
        SensorHero(selected, reading, history) { vm.selectSensor(null) }
        Spacer(Modifier.height(10.dp))
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionLabel("${sensors.size} sensors detected")
            sensors.forEach { sensor ->
                val active = selected == sensor
                SensorRow(sensor, active) { vm.selectSensor(if (active) null else sensor) }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}


// ───────────────────────── Tools ─────────────────────────
@Composable
private fun ToolsPage(orientation: DeviceOrientation?, error: String?) {
    val azimuth = orientation?.azimuthDegrees ?: 0f
    val pitch = orientation?.pitchDegrees ?: 0f
    val roll = orientation?.rollDegrees ?: 0f
    val animatedAzimuth by animateFloatAsState(azimuth, tween(100, easing = LinearEasing), label = "compassHeading")
    val animatedPitch by animateFloatAsState(pitch, tween(90, easing = LinearEasing), label = "levelPitch")
    val animatedRoll by animateFloatAsState(roll, tween(90, easing = LinearEasing), label = "levelRoll")
    PageColumn {
        SectionLabel("Precision tools")
        Text("LIVE DEVICE INSTRUMENTS", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
        Panel(accent = Lime) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("SPIRIT LEVEL", color = Lime, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Text("Accelerometer attitude", color = Muted, fontSize = 10.sp)
                }
                Text("PITCH / ROLL", color = Muted, fontSize = 8.sp)
            }
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                SpiritLevelVisual(animatedPitch, animatedRoll)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AngleReadout("PITCH", animatedPitch, Lime, Modifier.weight(1f))
                AngleReadout("ROLL", animatedRoll, Cyan, Modifier.weight(1f))
            }
            Text("Place the phone flat to center the bubble. Values are relative to the device's natural orientation.", color = Muted, fontSize = 9.sp)
        }
        Panel(accent = Magenta) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("DIGITAL COMPASS", color = Magenta, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Text("Magnetic heading • device top edge", color = Muted, fontSize = 10.sp)
                }
                Text("LIVE", color = Lime, fontSize = 9.sp, letterSpacing = 1.sp)
            }
            if (orientation?.hasMagnetometer == false) {
                Text("MAGNETOMETER NOT AVAILABLE", color = Coral, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("The spirit level remains available using the accelerometer.", color = Muted, fontSize = 9.sp)
            } else {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    CompassVisual(animatedAzimuth)
                }
                Text(
                    "%03.0f°  •  %s".format(Locale.US, animatedAzimuth, cardinalDirection(animatedAzimuth)),
                    color = Color.White, fontSize = 25.sp, fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
                )
                Text("Heading is magnetic and may be affected by nearby metal, magnets, and electrical equipment.", color = Muted, fontSize = 9.sp)
            }
        }
        if (orientation == null) {
            Panel(accent = Coral) {
                Text("SENSOR STATUS", color = Coral, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(error ?: "Waiting for accelerometer and magnetic-field sensor data…", color = Muted, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun AngleReadout(label: String, angle: Float, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = .09f)).padding(10.dp)) {
        Text(label, color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
        Text("%+.2f°".format(Locale.US, angle), color = accent, fontSize = 17.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SpiritLevelVisual(pitch: Float, roll: Float) {
    Canvas(Modifier.size(220.dp)) {
        val c = center
        val radius = size.minDimension * .43f
        drawCircle(Color(0xFF13232D), radius, c)
        drawCircle(Lime.copy(alpha = .7f), radius, c, style = Stroke(2.dp.toPx()))
        drawCircle(Cyan.copy(alpha = .25f), radius * .66f, c, style = Stroke(1.dp.toPx()))
        drawCircle(Cyan.copy(alpha = .25f), radius * .33f, c, style = Stroke(1.dp.toPx()))
        drawLine(Muted.copy(alpha = .65f), Offset(c.x - radius, c.y), Offset(c.x + radius, c.y), 1.dp.toPx())
        drawLine(Muted.copy(alpha = .65f), Offset(c.x, c.y - radius), Offset(c.x, c.y + radius), 1.dp.toPx())
        val maxOffset = radius * .62f
        val bx = (roll / 45f).coerceIn(-1f, 1f) * maxOffset
        val by = (pitch / 45f).coerceIn(-1f, 1f) * maxOffset
        val bubble = Offset(c.x + bx, c.y + by)
        drawCircle(Brush.radialGradient(listOf(Lime.copy(alpha = .65f), Lime.copy(alpha = .08f)), center = bubble, radius = 22.dp.toPx()), 22.dp.toPx(), bubble)
        drawCircle(Lime, 9.dp.toPx(), bubble)
        drawCircle(Color.White.copy(alpha = .8f), 3.dp.toPx(), Offset(bubble.x - 3.dp.toPx(), bubble.y - 3.dp.toPx()))
    }
}

@Composable
private fun CompassVisual(azimuth: Float) {
    Box(Modifier.size(220.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension * .43f
            drawCircle(Color(0xFF111C29), r, c)
            drawCircle(Magenta.copy(alpha = .65f), r, c, style = Stroke(2.dp.toPx()))
            drawCircle(Muted.copy(alpha = .3f), r * .78f, c, style = Stroke(1.dp.toPx()))
            rotate(-azimuth, c) {
                for (i in 0 until 72) {
                    val angle = i * 5f - 90f
                    val major = i % 6 == 0
                    val inner = if (major) r * .78f else r * .86f
                    drawLine(
                        if (major) Color.White.copy(alpha = .8f) else Muted.copy(alpha = .5f),
                        polar(c, inner, angle), polar(c, r * .94f, angle),
                        if (major) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }
            val needle = Path().apply {
                moveTo(c.x, c.y - r * .66f)
                lineTo(c.x - 9.dp.toPx(), c.y + 2.dp.toPx())
                lineTo(c.x, c.y - 7.dp.toPx())
                lineTo(c.x + 9.dp.toPx(), c.y + 2.dp.toPx())
                close()
            }
            drawPath(needle, Coral)
            drawCircle(Color.White, 4.dp.toPx(), c)
        }
        Box(Modifier.fillMaxSize().graphicsLayer { rotationZ = -azimuth }) {
            Text("N", color = Coral, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp))
            Text("E", color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterEnd).padding(end = 12.dp))
            Text("S", color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp))
            Text("W", color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterStart).padding(start = 12.dp))
        }
    }
}

private fun cardinalDirection(degrees: Float): String {
    val directions = listOf("N", "NE", "E", "SE", "S", "SW", "W", "NW")
    return directions[((degrees + 22.5f) / 45f).toInt().mod(8)]
}

@Composable
private fun SensorRow(sensor: Sensor, active: Boolean, onClick: () -> Unit) {
    val accent = sensorAccent(sensor.type)
    val bg by animateColorAsState(if (active) accent.copy(alpha = .16f) else Color(0x990C121B), tween(300), label = "rowBg")
    val border by animateColorAsState(if (active) accent else Color(0xFF1B2B38), tween(300), label = "rowBorder")
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(bg).border(1.dp, border, shape)
            .clickable(onClick = onClick).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(accent, CircleShape))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(sensor.name, color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${sensorLabel(sensor.type)}  •  ${sensor.vendor}", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(if (active) "STREAMING" else "TAP", color = if (active) accent else Muted, fontSize = 9.sp, letterSpacing = 1.sp)
    }
}

@Composable
private fun SensorHero(selected: Sensor?, reading: SensorReading?, history: List<Float>, onStop: () -> Unit) {
    val accent by animateColorAsState(sensorAccent(selected?.type), tween(500), label = "accent")
    val inf = rememberInfiniteTransition(label = "heroInf")
    val blink by inf.animateFloat(0.25f, 1f, infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "blink")
    Panel(accent = accent) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (selected == null) "STANDBY" else sensorLabel(selected.type),
                    color = accent, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold
                )
                Text(
                    selected?.name ?: "Select a sensor below to start streaming",
                    color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (selected != null) {
                Box(Modifier.size(8.dp).graphicsLayer { alpha = blink }.background(Coral, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text("LIVE", color = Coral, fontSize = 9.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                TextButton(onClick = onStop) { Text("STOP", color = accent, fontSize = 10.sp, letterSpacing = 1.sp) }
            }
        }
        Crossfade(targetState = selected?.type, animationSpec = tween(450), label = "visual") { type ->
            Box(Modifier.fillMaxWidth().height(164.dp), contentAlignment = Alignment.Center) {
                SensorVisual(type, reading?.values ?: emptyList(), selected, history, accent)
            }
        }
        if (selected != null) {
            ValueChips(reading?.values ?: emptyList(), accent)
            Waveform(history, accent)
        }
    }
}

@Composable
private fun ValueChips(values: List<Float>, accent: Color) {
    val labels = listOf("X", "Y", "Z")
    val shown = values.take(3)
    if (shown.isEmpty()) {
        Text("Waiting for sensor event…", color = Muted, fontSize = 11.sp)
        return
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        shown.forEachIndexed { i, v ->
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(accent.copy(alpha = .09f)).padding(horizontal = 9.dp, vertical = 6.dp)
            ) {
                Text(if (shown.size == 1) "VALUE" else labels[i], color = Muted, fontSize = 8.sp, letterSpacing = 1.sp)
                Text("%.3f".format(Locale.US, v), color = accent, fontSize = 13.sp, fontFamily = FontFamily.Monospace, maxLines = 1)
            }
        }
    }
}

@Composable
private fun Waveform(values: List<Float>, color: Color) {
    Canvas(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x66000000))) {
        for (i in 1..3) {
            val gy = size.height * i / 4f
            drawLine(Color(0xFF1B2B38), Offset(0f, gy), Offset(size.width, gy), 1f)
        }
        if (values.size > 1) {
            val mn = values.minOrNull() ?: 0f
            val mx = values.maxOrNull() ?: 1f
            val range = if (mx - mn < 1e-6f) 1f else mx - mn
            val pad = 5.dp.toPx()
            val path = Path()
            var last = Offset.Zero
            values.forEachIndexed { i, v ->
                val p = Offset(i * size.width / (values.size - 1), size.height - pad - ((v - mn) / range) * (size.height - 2 * pad))
                if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
                last = p
            }
            val fill = Path()
            fill.addPath(path)
            fill.lineTo(size.width, size.height)
            fill.lineTo(0f, size.height)
            fill.close()
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = .35f), Color.Transparent)))
            drawPath(path, color.copy(alpha = .30f), style = Stroke(6.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(path, color, style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawCircle(Color.White, 3.dp.toPx(), last)
        }
    }
}

// ───────────────────────── Per-sensor animations ─────────────────────────
@Composable
private fun SensorVisual(type: Int?, values: List<Float>, sensor: Sensor?, history: List<Float>, accent: Color) {
    val v0 = values.firstOrNull() ?: 0f
    when (type) {
        null -> RadarVisual(accent)
        Sensor.TYPE_ACCELEROMETER, Sensor.TYPE_GRAVITY -> BubbleVisual(values, 10f, accent)
        Sensor.TYPE_LINEAR_ACCELERATION -> BubbleVisual(values, 4f, accent)
        Sensor.TYPE_MAGNETIC_FIELD, Sensor.TYPE_MAGNETIC_FIELD_UNCALIBRATED -> CompassVisual(values, accent)
        Sensor.TYPE_GYROSCOPE, Sensor.TYPE_GYROSCOPE_UNCALIBRATED -> GyroVisual(values, accent)
        Sensor.TYPE_ROTATION_VECTOR, Sensor.TYPE_GAME_ROTATION_VECTOR, Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR ->
            RotationVisual(values, accent)
        Sensor.TYPE_LIGHT -> LightVisual(v0, accent)
        Sensor.TYPE_PROXIMITY -> ProximityVisual(v0, sensor?.maximumRange ?: 5f, accent)
        Sensor.TYPE_PRESSURE -> GaugeVisual((v0 - 950f) / 100f, "%.1f".format(Locale.US, v0), "hPa", accent)
        Sensor.TYPE_RELATIVE_HUMIDITY -> GaugeVisual(v0 / 100f, "%.0f".format(Locale.US, v0), "% RH", accent)
        Sensor.TYPE_AMBIENT_TEMPERATURE -> GaugeVisual((v0 + 10f) / 55f, "%.1f".format(Locale.US, v0), "°C", accent)
        else -> PulseVisual(history, accent)
    }
}

/** Idle radar shown when no sensor is selected. */
@Composable
private fun RadarVisual(accent: Color) {
    val inf = rememberInfiniteTransition(label = "radar")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "radarSpin")
    Canvas(Modifier.size(160.dp)) {
        val c = center
        val r = size.minDimension / 2f - 4.dp.toPx()
        for (i in 1..4) drawCircle(accent.copy(alpha = 0.16f), r * i / 4f, c, style = Stroke(1.dp.toPx()))
        drawLine(accent.copy(alpha = 0.2f), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.dp.toPx())
        drawLine(accent.copy(alpha = 0.2f), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.dp.toPx())
        val tl = Offset(c.x - r, c.y - r)
        for (i in 0 until 14) {
            val a = (spin - i * 3f)
            drawArc(accent.copy(alpha = 0.32f * (1f - i / 14f)), a, 3.2f, true, tl, Size(r * 2f, r * 2f))
        }
        drawLine(accent, c, polar(c, r, spin), 2.dp.toPx(), cap = StrokeCap.Round)
        drawCircle(accent, 3.dp.toPx(), c)
    }
}

/** Accelerometer / gravity / linear acceleration: a floating orb on a target. */
@Composable
private fun BubbleVisual(values: List<Float>, scale: Float, accent: Color) {
    val x by animateFloatAsState(values.getOrElse(0) { 0f }, tween(120, easing = LinearEasing), label = "bx")
    val y by animateFloatAsState(values.getOrElse(1) { 0f }, tween(120, easing = LinearEasing), label = "by")
    val z by animateFloatAsState(values.getOrElse(2) { 0f }, tween(120, easing = LinearEasing), label = "bz")
    val inf = rememberInfiniteTransition(label = "bubble")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "bubbleSpin")
    Canvas(Modifier.size(160.dp)) {
        val c = center
        val r = size.minDimension / 2f - 4.dp.toPx()
        for (i in 1..3) drawCircle(accent.copy(alpha = 0.10f + 0.05f * i), r * i / 3f, c, style = Stroke(1.dp.toPx()))
        drawLine(accent.copy(alpha = 0.25f), Offset(c.x - r, c.y), Offset(c.x + r, c.y), 1.dp.toPx())
        drawLine(accent.copy(alpha = 0.25f), Offset(c.x, c.y - r), Offset(c.x, c.y + r), 1.dp.toPx())
        rotate(spin, c) {
            drawLine(accent.copy(alpha = 0.45f), polar(c, r * 0.9f, 0f), polar(c, r, 0f), 3.dp.toPx())
            drawLine(accent.copy(alpha = 0.45f), polar(c, r * 0.9f, 180f), polar(c, r, 180f), 3.dp.toPx())
        }
        val limit = r * 0.82f
        var dx = (-x / scale) * limit
        var dy = (y / scale) * limit
        val len = sqrt(dx * dx + dy * dy)
        if (len > limit) {
            dx *= limit / len
            dy *= limit / len
        }
        val pos = Offset(c.x + dx, c.y + dy)
        val orb = (11.dp.toPx() + (z / scale) * 5.dp.toPx()).coerceIn(6.dp.toPx(), 18.dp.toPx())
        drawLine(accent.copy(alpha = 0.35f), c, pos, 1.5.dp.toPx())
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.6f), Color.Transparent), center = pos, radius = orb * 3f), radius = orb * 3f, center = pos)
        drawCircle(accent, orb, pos, style = Stroke(2.dp.toPx()))
        drawCircle(Color.White, orb * 0.4f, pos)
    }
}

/** Magnetometer: compass with a needle pointing along the field in the device plane. */
@Composable
private fun CompassVisual(values: List<Float>, accent: Color) {
    val mx by animateFloatAsState(values.getOrElse(0) { 0f }, tween(150, easing = LinearEasing), label = "mx")
    val my by animateFloatAsState(values.getOrElse(1) { 0f }, tween(150, easing = LinearEasing), label = "my")
    val magnitude = sqrt(values.take(3).sumOf { (it * it).toDouble() }).toFloat()
    Box(Modifier.size(160.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = size.minDimension / 2f - 4.dp.toPx()
            drawCircle(accent.copy(alpha = 0.35f), r, c, style = Stroke(1.5.dp.toPx()))
            for (i in 0 until 36) {
                val major = i % 9 == 0
                val a = i * 10f - 90f
                drawLine(
                    accent.copy(alpha = if (major) 0.9f else 0.4f),
                    polar(c, if (major) r * 0.8f else r * 0.9f, a), polar(c, r, a),
                    if (major) 2.dp.toPx() else 1.dp.toPx()
                )
            }
            val deg = atan2(mx, my) / DEG
            val needle = Path().apply {
                moveTo(c.x, c.y - r * 0.72f)
                lineTo(c.x - 7.dp.toPx(), c.y)
                lineTo(c.x + 7.dp.toPx(), c.y)
                close()
            }
            val tail = Path().apply {
                moveTo(c.x, c.y + r * 0.72f)
                lineTo(c.x - 7.dp.toPx(), c.y)
                lineTo(c.x + 7.dp.toPx(), c.y)
                close()
            }
            rotate(deg, c) {
                drawPath(needle, Magenta)
                drawPath(tail, accent.copy(alpha = 0.45f))
                drawCircle(Color.White, 3.dp.toPx(), c)
            }
        }
        Text(
            "%.0f µT".format(Locale.US, magnitude), color = Color.White, fontSize = 10.sp,
            fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

/** Gyroscope: gimbal rings that turn with the integrated angular velocity. */
@Composable
private fun GyroVisual(values: List<Float>, accent: Color) {
    val wx by rememberUpdatedState(values.getOrElse(0) { 0f })
    val wy by rememberUpdatedState(values.getOrElse(1) { 0f })
    val wz by rememberUpdatedState(values.getOrElse(2) { 0f })
    var ax by remember { mutableFloatStateOf(0f) }
    var ay by remember { mutableFloatStateOf(0f) }
    var az by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = (now - last) / 1_000_000_000f
                    ax += wx * dt * 57.29578f
                    ay += wy * dt * 57.29578f
                    az += wz * dt * 57.29578f
                }
                last = now
            }
        }
    }
    GimbalCanvas({ ax }, { ay }, { az }, accent)
}

/** Rotation-vector sensors: gimbal rings showing the absolute device attitude. */
@Composable
private fun RotationVisual(values: List<Float>, accent: Color) {
    var azimuth = 0f
    var pitch = 0f
    var roll = 0f
    if (values.size >= 3) {
        val matrix = FloatArray(9)
        val orientation = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(matrix, values.take(4).toFloatArray())
        SensorManager.getOrientation(matrix, orientation)
        azimuth = orientation[0] / DEG
        pitch = orientation[1] / DEG
        roll = orientation[2] / DEG
    }
    val az by animateFloatAsState(azimuth, tween(110, easing = LinearEasing), label = "az")
    val pi by animateFloatAsState(pitch, tween(110, easing = LinearEasing), label = "pi")
    val ro by animateFloatAsState(roll, tween(110, easing = LinearEasing), label = "ro")
    GimbalCanvas({ pi }, { ro }, { az }, accent)
}

@Composable
private fun GimbalCanvas(ax: () -> Float, ay: () -> Float, az: () -> Float, accent: Color) {
    val inf = rememberInfiniteTransition(label = "gimbal")
    val pulse by inf.animateFloat(0.3f, 0.8f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "gimbalPulse")
    Canvas(Modifier.size(160.dp)) {
        val c = center
        val r = size.minDimension / 2f - 6.dp.toPx()
        val a1 = ax() * DEG
        val a2 = ay() * DEG
        val a3 = az()
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = pulse * 0.55f), Color.Transparent), center = c, radius = r * 0.5f), radius = r * 0.5f, center = c)
        // Ring Z (flat circle, rotates in plane)
        drawCircle(accent.copy(alpha = 0.55f), r, c, style = Stroke(1.5.dp.toPx()))
        drawCircle(Color.White, 3.5.dp.toPx(), polar(c, r, a3 - 90f))
        // Ring X (ellipse narrowing with a1)
        val wX = max(abs(cos(a1)) * r * 0.9f, 2f)
        drawOval(Violet.copy(alpha = 0.85f), Offset(c.x - wX, c.y - r * 0.9f), Size(wX * 2f, r * 1.8f), style = Stroke(1.5.dp.toPx()))
        drawCircle(Color.White, 3.dp.toPx(), Offset(c.x + r * 0.9f * cos(a1) * cos(a1), c.y + r * 0.9f * sin(a1)))
        // Ring Y (ellipse narrowing with a2)
        val hY = max(abs(cos(a2)) * r * 0.9f, 2f)
        drawOval(Magenta.copy(alpha = 0.85f), Offset(c.x - r * 0.9f, c.y - hY), Size(r * 1.8f, hY * 2f), style = Stroke(1.5.dp.toPx()))
        drawCircle(Color.White, 3.dp.toPx(), Offset(c.x + r * 0.9f * sin(a2), c.y + r * 0.9f * cos(a2) * sin(a2)))
        drawCircle(Color.White, 2.5.dp.toPx(), c)
    }
}

/** Light sensor: a sun whose core and rays grow with the logarithm of the lux value. */
@Composable
private fun LightVisual(lux: Float, accent: Color) {
    val frac by animateFloatAsState((log10(1f + lux.coerceAtLeast(0f)) / 5f).coerceIn(0f, 1f), tween(140, easing = LinearEasing), label = "lux")
    val inf = rememberInfiniteTransition(label = "sun")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "sunSpin")
    val breathe by inf.animateFloat(0.8f, 1f, infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "sunBreathe")
    Box(Modifier.size(160.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val maxR = size.minDimension / 2f
            val core = maxR * (0.20f + 0.30f * frac)
            val glowR = maxR * (0.55f + 0.45f * frac)
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.55f * breathe), Color.Transparent), center = c, radius = glowR), radius = glowR, center = c)
            for (i in 0 until 24) {
                val a = i * 15f + spin
                val len = core * 1.25f + (maxR - core * 1.25f) * (0.25f + 0.6f * frac) * (if (i % 2 == 0) 1f else 0.7f) * breathe
                drawLine(accent.copy(alpha = 0.8f), polar(c, core * 1.2f, a), polar(c, len, a), 2.dp.toPx(), cap = StrokeCap.Round)
            }
            drawCircle(Brush.radialGradient(listOf(Color.White, accent), center = c, radius = core), radius = core, center = c)
        }
        Text(
            (if (lux < 100f) "%.1f lx" else "%.0f lx").format(Locale.US, lux), color = Color.White, fontSize = 10.sp,
            fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

/** Proximity: calm outward ripples when far, tight inward ripples when something is near. */
@Composable
private fun ProximityVisual(value: Float, maxRange: Float, accent: Color) {
    val near = value < maxRange
    val nearF by animateFloatAsState(if (near) 1f else 0f, tween(350), label = "near")
    val inf = rememberInfiniteTransition(label = "prox")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1700, easing = LinearEasing)), label = "proxT")
    Box(Modifier.size(160.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val maxR = size.minDimension / 2f
            val col = lerp(accent, Coral, nearF)
            for (i in 0 until 3) {
                val p = (t + i / 3f) % 1f
                val q = if (near) 1f - p else p
                drawCircle(col.copy(alpha = (1f - p) * 0.7f), maxR * (0.2f + 0.8f * q), c, style = Stroke(2.dp.toPx()))
            }
            val orb = (12.dp.toPx() + 6.dp.toPx() * nearF)
            drawCircle(Brush.radialGradient(listOf(col.copy(alpha = 0.6f), Color.Transparent), center = c, radius = orb * 2.6f), radius = orb * 2.6f, center = c)
            drawCircle(col, orb, c)
            drawCircle(Color.White, orb * 0.35f, c)
        }
        Text(
            if (near) "NEAR" else "FAR", color = lerp(accent, Coral, nearF), fontSize = 10.sp,
            letterSpacing = 2.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

/** Pressure / humidity / temperature: animated arc gauge. */
@Composable
private fun GaugeVisual(fraction: Float, valueText: String, unit: String, accent: Color) {
    RingCanvas(fraction, accent, Modifier.size(156.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(valueText, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Light)
            Text(unit, color = accent, fontSize = 10.sp, letterSpacing = 1.sp)
        }
    }
}

/** Any other sensor: a pulsing orb with orbiting particles driven by the live signal. */
@Composable
private fun PulseVisual(history: List<Float>, accent: Color) {
    val last = history.lastOrNull() ?: 0f
    val mn = history.minOrNull() ?: 0f
    val mx = history.maxOrNull() ?: 1f
    val norm = if (mx - mn < 1e-6f) 0.5f else (last - mn) / (mx - mn)
    val n by animateFloatAsState(norm, tween(160), label = "pulseN")
    val inf = rememberInfiniteTransition(label = "pulse")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "pulseSpin")
    Canvas(Modifier.size(160.dp)) {
        val c = center
        val r = size.minDimension / 2f - 4.dp.toPx()
        for (k in 0 until 3) {
            val orbit = r * (0.45f + 0.22f * k)
            drawCircle(accent.copy(alpha = 0.18f), orbit, c, style = Stroke(1.dp.toPx()))
            val a = spin * (1f + 0.5f * k) * (if (k % 2 == 0) 1f else -1f) + k * 120f
            val p = polar(c, orbit, a)
            drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.7f), Color.Transparent), center = p, radius = 10.dp.toPx()), radius = 10.dp.toPx(), center = p)
            drawCircle(Color.White, 2.5.dp.toPx(), p)
        }
        val orb = r * (0.18f + 0.22f * n)
        drawCircle(Brush.radialGradient(listOf(accent.copy(alpha = 0.7f), Color.Transparent), center = c, radius = orb * 2.4f), radius = orb * 2.4f, center = c)
        drawCircle(Brush.radialGradient(listOf(Color.White, accent), center = c, radius = orb), radius = orb, center = c)
    }
}

// ───────────────────────── Settings ─────────────────────────
@Composable
private fun SettingsDialog(fx: Float, onFx: (Float) -> Unit, sampling: Int, onSampling: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0C121B),
        title = { Text("NEXUS CONFIGURATION", color = Cyan, fontSize = 15.sp, letterSpacing = 1.4.sp) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Background effects intensity", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
                Slider(
                    value = fx, onValueChange = onFx,
                    colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan)
                )
                Text("Sensor sampling rate", color = MaterialTheme.colorScheme.onSurface, fontSize = 12.sp)
                listOf(
                    "NORMAL (≈ 200 ms)" to SensorManager.SENSOR_DELAY_NORMAL,
                    "UI (≈ 60 ms)" to SensorManager.SENSOR_DELAY_UI,
                    "FASTEST (hardware dependent)" to SensorManager.SENSOR_DELAY_FASTEST
                ).forEach { (label, value) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = sampling == value, onClick = { onSampling(value) },
                            colors = RadioButtonDefaults.colors(selectedColor = Cyan)
                        )
                        Text(label, color = Muted, fontSize = 10.sp)
                    }
                }
                Text("NEXUS 1.1.0  •  Offline / no analytics / no network permission", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("CLOSE", color = Cyan) } }
    )
}
