package dev.nexus.systemintelligence.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexusDark = darkColorScheme(
    primary = Color(0xFF67E8F9), secondary = Color(0xFF9B8CFF),
    background = Color(0xFF05080D), surface = Color(0xFF0C121B),
    onBackground = Color(0xFFE5F3F7), onSurface = Color(0xFFE5F3F7),
    outline = Color(0xFF203746)
)

@Composable
fun NexusTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NexusDark, content = content)
}
