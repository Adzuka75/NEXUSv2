# NEXUS – System Intelligence

A native Kotlin + Jetpack Compose Android system and sensor dashboard. NEXUS runs locally and has no backend, analytics, account system, or network permission.

## Features

- Live device, Android, display, uptime and storage information
- RAM statistics from `ActivityManager`
- Battery level, status, temperature, voltage and technology from the system battery broadcast
- Sensor discovery and on-demand live readings through `SensorManager`
- Session signal graph for the selected sensor
- Device feature inventory and build fingerprint
- Compose-based dark futuristic interface and six-section navigation
- Tools screen with an accelerometer-driven spirit level and magnetometer/accelerometer compass
- Pitch and roll angle readouts, smoothed bubble movement, compass heading and cardinal markers
- Lifecycle-aware sensor streams with guarded registration/unregistration and missing-hardware fallbacks
- Responsive lux filtering that preserves subtle changes while damping sensor noise

## Accuracy and Android limitations

Android intentionally restricts some system metrics for ordinary applications. CPU utilization, per-core frequency, battery cycle count, battery health percentage and charging wattage are not fabricated. They are labelled unavailable or not exposed when the public SDK does not provide a reliable value. Sensor availability varies by device. Sensor streams are registered only while a sensor is selected or the Tools screen is active. Streams are paused when the app leaves the foreground and unregistered on cancellation, selection changes, or ViewModel cleanup. The spirit level works with an accelerometer alone; compass heading additionally requires a magnetic-field sensor.

The current release samples the device snapshot every 1.5 seconds while the app process is active. It does not run a background service.

## Build locally

Requirements: Android Studio with JDK 17 and Android SDK Platform 35.

1. Open this repository in Android Studio.
2. Allow Gradle sync to complete.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

Or install Gradle 8.9 and run:

```bash
gradle assembleDebug
```

## Build with GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this project (the `settings.gradle.kts` file must be at repository root).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **NEXUS Android APK** using **Run workflow**, or push to `main`.
5. Open the completed workflow run.
6. Download the `NEXUS-debug-apk` artifact.
7. Extract the ZIP and install `app-debug.apk` on your Android device. You may need to allow installation from the browser or file manager used to open it.

The workflow uses GitHub-hosted runners and free GitHub Actions minutes within the limits of your account.

## Privacy

The manifest requests no dangerous permissions and declares no internet permission. All displayed values are obtained from Android public APIs on-device.
